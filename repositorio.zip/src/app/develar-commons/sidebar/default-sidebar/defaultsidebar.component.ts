import { Component, OnInit} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'sidebar',
  templateUrl: './defaultsidebar.component.html',
  styleUrls: ['./defaultsidebar.component.scss'],
})
export class DefaultSidebarComponent implements OnInit {
  constructor( ) { }

  ngOnInit() { }
}