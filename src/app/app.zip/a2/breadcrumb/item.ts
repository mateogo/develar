export class Item {
  title: string;
  icon:  string;
  link:  string;
}