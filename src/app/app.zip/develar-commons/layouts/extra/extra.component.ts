import { Component } from '@angular/core';
import { SharedService } from '../../shared-service';

@Component({
  moduleId: module.id,
  selector: 'extra-layout',
  templateUrl: 'extra.component.html',
  styleUrls: ['extra.component.scss']
})
export class ExtraLayoutComponent {

}