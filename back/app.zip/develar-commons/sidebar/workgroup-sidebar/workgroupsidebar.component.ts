import { Component, OnInit} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'workgroup-sidebar',
  templateUrl: './workgroupsidebar.component.html',
  styleUrls: ['./workgroupsidebar.component.scss'],
})
export class WorkgroupSidebarComponent implements OnInit {
  constructor( ) { }

  ngOnInit() { }
}